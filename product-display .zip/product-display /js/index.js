$(document).ready(function () {
  // GraphQL query to fetch products data
  const query = `query {
			products (limit: 50) {
				products {
					name
					price
					listPrice
					brand
					imageUrl
					alternateImageUrls
					url
					scores {
						week {
							views
							buys
						}
					}
				}
			}
		}`;

  // Request header with authorization token
  const headers = {
    "Content-Type": "application/graphql",
    Authorization:
      "Basic " +
      btoa(
        ":" + "F7k5O1PHyzjwbjQF8Z6UvvZGuu90l3M5WR8Lp8gNoP8nwEQ6zpavKNVUajlZrX6x"
      ),
  };

  // Send the GraphQL query using jQuery's AJAX function
  $.ajax({
    url: "https://api.nosto.com/v1/graphql",
    type: "POST",
    headers: headers,
    data: query,
    success: function (response) {
      // Extract the products data from the response
      const products = response.data.products.products;
      console.log(products);

      // Create the BEST SELLER product card
      const bestSeller = products.reduce((a, b) =>
        a.scores.week.buys > b.scores.week.buys ? a : b
      );

      // Set the BEST SELLER THIS WEEK product
      $(".best-seller-img").attr("src", bestSeller.imageUrl);
      $(".best-seller-img").attr("alt", bestSeller.name);
      $(".best-seller-img").parent().attr("href", bestSeller.url);
      $(".best-seller-tag").text("BEST SELLER THIS WEEK!");

      // Sort most viewed products excluded best seller
      let sortedProducts = products
        .filter((product) => product !== bestSeller)
        .sort((a, b) => b.scores.week.views - a.scores.week.views);

      // Iterate through the products and create a product card for each one
      sortedProducts.forEach((product, index) => {
        // Add "MOST VIEWED" label to the first product card
        let labelHtml = "";
        if (index === 0) {
          labelHtml = `<span class="most-view-label">MOST VIEWED!</span>`;
        }

        // Check if the product has an alternate image and use it if available
        let imageUrl = product.imageUrl;
        if (
          product.alternateImageUrls &&
          product.alternateImageUrls.length > 0
        ) {
          imageUrl = product.alternateImageUrls[0];
        }

        // Format price
        let price = product.price.toFixed(2).replace(/\.00$/, "");
        let listPrice = product.listPrice.toFixed(2).replace(/\.00$/, "");

        // Show the price and listPrice only if they are different
        let priceHtml = "";
        if (price === listPrice) {
          priceHtml = `<span class="price">$${price}</span>`;
        } else {
          priceHtml = `<span class="price">$${price}</span><span class="actual-price">$${listPrice}</span>`;
        }

        // Truncate name if too long
        let name =
          product.name.length > 20
            ? product.name.slice(0, 20) + "..."
            : product.name;

        // Create product card
        let productCard = `
        <div class="product-card">
          <div class="product-image">
       ${labelHtml}
            <a href="${product.url}" class="product-link"><img src="${imageUrl}" class="product-thumb" alt="${product.name}" /></a>
          </div>
          <div class="product-info">
            <h2 class="product-brand">${product.brand}</h2>
            <p class="product-name">${name}</p>
          ${priceHtml}
          </div>
        </div>
      `;

        // Add the product card to the product carousel
        $(".product-carousel").append(productCard);

        // Add hover event listener to the product's card
        $(".product-card:last-child").hover(
          function () {
            // Replace the image with the alternate image if available
            if (product.alternateImageUrls && product.alternateImageUrls[0]) {
              $(".product-thumb", this).attr(
                "src",
                product.alternateImageUrls[0]
              );
            }
          },
          function () {
            // Restore the original image
            $(".product-thumb", this).attr("src", product.imageUrl);
          }
        );

        //Clicking on a product image, redirect the user to the product page
        $(".product-link").click(function (event) {
          event.preventDefault();
          const productUrl = $(this).attr("href");
          window.location.href = productUrl;
        });
      });
      slick_active();
    },
    error: function (error) {
      console.log(error);
    },
  });

  // Set up carousel with Slick plugin
  function slick_active() {
    $(".product-carousel").slick({
      dots: false,
      infinite: true,
      slidesToShow: 3,
      slidesToScroll: 1,
      arrow: true,
      centerPadding: "30px",
      prevArrow:
        "<button type='button' class='slick-prev pull-left'><img src='images/right.png'></button>",
      nextArrow:
        "<button type='button' class='slick-next pull-right'><img src='images/left.png'></button>",
      responsive: [
        {
          breakpoint: 1026,
          settings: {
            slidesToShow: 2,
            slidesToScroll: 1,
            infinite: true,
            dots: true,
          },
        },

        {
          breakpoint: 575,
          settings: {
            slidesToShow: 2.5,
            slidesToScroll: 1,
          },
        },
      ],
    });
  }
  // Set up carousel with Slick plugin
});
